<?php
// Start the session
session_start();

// Check if the user is logged in and has the appropriate level
if (!isset($_SESSION['user_id']) || ($_SESSION['user_level'] !== 'admin' && $_SESSION['user_level'] !== 'pimpinan')) {
    header("location: login.php"); // Redirect to login if not logged in or not authorized
    exit;
}

// Include database connection
include('db.php');

// Fetch users from the database
$sql = "SELECT * FROM users";
$result = $conn->query($sql);

// Check for errors
if ($conn->error) {
    die("Error fetching users: " . $conn->error);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pengguna - Sistem Informasi Sewa Alat Musik</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to your styles -->
</head>
<body>
    <div class="container">
        <h2>Daftar Pengguna</h2>

        <p><a href="logout.php">Logout</a></p> <!-- Logout link -->

        <?php if ($result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>User Level</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['user_id']); ?></td>
                            <td><?php echo htmlspecialchars($row['username']); ?></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td><?php echo htmlspecialchars($row['phone']); ?></td>
                            <td><?php echo htmlspecialchars($row['user_level']); ?></td>
                            <td>
                                <!-- Action buttons: View, Edit, Delete (you can add more functionality here) -->
                                <a href="edit_user.php?id=<?php echo $row['user_id']; ?>">Edit</a> |
                                <a href="delete_user.php?id=<?php echo $row['user_id']; ?>" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No users found.</p>
        <?php endif; ?>

    </div>

    <style>
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        a {
            text-decoration: none;
            color: #007BFF;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</body>
</html>

<?php
// Close the connection
$conn->close();
?>
