<?php
session_start();

// Check if user is logged in and has the 'pimpinan' role
if (!isset($_SESSION['user_id']) || $_SESSION['user_level'] !== 'pimpinan') {
    header("Location: login.php");
    exit;
}

// Database connection
$host = "localhost";
$user = "root";
$password = "";
$dbname = "music_rental";

$conn = new mysqli($host, $user, $password, $dbname);

// Check database connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get transaction statistics
$transaksi_query = "SELECT COUNT(*) AS total_transaksi, SUM(total_price) AS total_pendapatan
                    FROM rentals WHERE status = 'completed'";
$transaksi_result = $conn->query($transaksi_query);
$transaksi_data = $transaksi_result->fetch_assoc();

// Get available instruments
$instrument_query = "SELECT COUNT(*) AS total_instruments_available FROM instruments WHERE availability = 1";
$instrument_result = $conn->query($instrument_query);
$instrument_data = $instrument_result->fetch_assoc();

// Get registered users
$user_query = "SELECT COUNT(*) AS total_users FROM users";
$user_result = $conn->query($user_query);
$user_data = $user_result->fetch_assoc();

// Handle PDF generation
if (isset($_GET['generate_pdf'])) {
    require('fpdf/fpdf.php');
    $pdf = new FPDF();
    $pdf->AddPage();
    
    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(200, 10, 'Laporan Pimpinan', 0, 1, 'C');
    $pdf->Ln(10);

    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(100, 10, 'Total Transaksi Selesai: ' . $transaksi_data['total_transaksi'], 0, 1);
    $pdf->Cell(100, 10, 'Pendapatan: Rp ' . number_format($transaksi_data['total_pendapatan'], 2, ',', '.'), 0, 1);
    $pdf->Ln(5);

    $pdf->Cell(100, 10, 'Alat Musik Tersedia: ' . $instrument_data['total_instruments_available'], 0, 1);
    $pdf->Ln(5);

    $pdf->Cell(100, 10, 'Total Pengguna Terdaftar: ' . $user_data['total_users'], 0, 1);
    $pdf->Ln(10);

    $pdf->Cell(200, 10, 'Riwayat Transaksi', 0, 1, 'C');
    $pdf->Ln(5);

    $pdf->Cell(20, 10, 'No', 1, 0, 'C');
    $pdf->Cell(40, 10, 'Username', 1, 0, 'C');
    $pdf->Cell(50, 10, 'Nama Alat Musik', 1, 0, 'C');
    $pdf->Cell(30, 10, 'Tanggal Sewa', 1, 0, 'C');
    $pdf->Cell(30, 10, 'Tanggal Kembali', 1, 0, 'C');
    $pdf->Cell(30, 10, 'Total Harga', 1, 1, 'C');

    $transaksi_query = "SELECT r.rental_id, u.username, i.name AS instrument_name, r.rental_date, r.return_date, r.total_price
                        FROM rentals r
                        JOIN users u ON r.user_id = u.user_id
                        JOIN instruments i ON r.instrument_id = i.instrument_id";
    $transaksi_result = $conn->query($transaksi_query);

    if ($transaksi_result->num_rows > 0) {
        $no = 1;
        while ($row = $transaksi_result->fetch_assoc()) {
            $pdf->Cell(20, 10, $no++, 1, 0, 'C');
            $pdf->Cell(40, 10, $row['username'], 1, 0, 'C');
            $pdf->Cell(50, 10, $row['instrument_name'], 1, 0, 'C');
            $pdf->Cell(30, 10, $row['rental_date'], 1, 0, 'C');
            $pdf->Cell(30, 10, $row['return_date'] ?? '-', 1, 0, 'C');
            $pdf->Cell(30, 10, 'Rp ' . number_format($row['total_price'], 2, ',', '.'), 1, 1, 'C');
        }
    } else {
        $pdf->Cell(180, 10, 'Tidak ada transaksi', 1, 1, 'C');
    }

    $pdf->Output();
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pimpinan Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            background: url('https://th.bing.com/th/id/OIP.wukVh5S9da2UGB8n-qgE9AHaFj?rs=1&pid=ImgDetMain') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Poppins', sans-serif;
            color: #333;
            padding-top: 60px;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
        }

        h1, h2 {
            color: #2C3E50;
            font-weight: 600;
            margin-bottom: 30px;
        }

        .card {
            border-radius: 10px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }

        .card-header {
            background-color: #2980b9;
            color: white;
            text-align: center;
            font-size: 1.25rem;
            font-weight: bold;
            border-radius: 10px 10px 0 0;
        }

        .card-body {
            padding: 20px;
            text-align: center;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0px 8px 30px rgba(0, 0, 0, 0.15);
        }

        .btn {
            border-radius: 25px;
            font-weight: bold;
            font-size: 1rem;
            padding: 10px 30px;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background-color: #2980b9;
            border-color: #2980b9;
        }

        .btn-primary:hover {
            background-color: #1c5980;
            border-color: #1c5980;
        }

        .btn-danger {
            background-color: #e74c3c;
            border-color: #e74c3c;
        }

        .btn-danger:hover {
            background-color: #c0392b;
            border-color: #c0392b;
        }

        .table th, .table td {
            text-align: center;
            vertical-align: middle;
            font-size: 1.1rem;
        }

        .table th {
            background-color: #2980b9;
            color: white;
            font-weight: bold;
        }

        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #f9f9f9;
        }

        .table-bordered {
            border: 1px solid #ddd;
        }

        .footer {
            text-align: center;
            padding: 20px;
            background-color: #f4f7fc;
            margin-top: 40px;
            border-radius: 0 0 15px 15px;
        }

        .footer p {
            color: #555;
            font-size: 1rem;
        }

        /* Responsive Design */
        @media (max-width: 767px) {
            .card-body p {
                font-size: 0.9rem;
            }

            .container {
                padding: 20px;
            }

            .btn {
                padding: 8px 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Boss Muda</h1>

        <nav class="d-flex justify-content-between mb-4">
            <a href="logout.php" class="btn btn-danger">Logout</a>
            <a href="pimpinan_dashboard.php?generate_pdf=true" class="btn btn-primary">Cetak Laporan PDF</a>
        </nav>

        <div class="row">
            <!-- Statistik Transaksi -->
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-header">
                        Total Transaksi Selesai
                    </div>
                    <div class="card-body">
                        <p><?php echo $transaksi_data['total_transaksi']; ?> transaksi</p>
                        <p>Pendapatan: Rp <?php echo number_format($transaksi_data['total_pendapatan'], 2, ',', '.'); ?></p>
                    </div>
                </div>
            </div>

            <!-- Statistik Alat Musik Tersedia -->
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-header">
                        Alat Musik Tersedia
                    </div>
                    <div class="card-body">
                        <p><?php echo $instrument_data['total_instruments_available']; ?> alat musik tersedia</p>
                    </div>
                </div>
            </div>

            <!-- Statistik Pengguna -->
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-header">
                        Total Pengguna
                    </div>
                    <div class="card-body">
                        <p><?php echo $user_data['total_users']; ?> pengguna terdaftar</p>
                    </div>
                </div>
            </div>
        </div>

        <h2 class="mb-4">Riwayat Transaksi</h2>
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Username</th>
                    <th>Nama Alat Musik</th>
                    <th>Tanggal Sewa</th>
                    <th>Tanggal Kembali</th>
                    <th>Total Harga</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $transaksi_query = "SELECT r.rental_id, u.username, i.name AS instrument_name, r.rental_date, r.return_date, r.total_price, r.status
                                    FROM rentals r
                                    JOIN users u ON r.user_id = u.user_id
                                    JOIN instruments i ON r.instrument_id = i.instrument_id";
                $transaksi_result = $conn->query($transaksi_query);

                if ($transaksi_result->num_rows > 0) {
                    $no = 1;
                    while ($row = $transaksi_result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $no++ . "</td>";
                        echo "<td>" . htmlspecialchars($row['username']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['instrument_name']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['rental_date']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['return_date'] ?? '-') . "</td>";
                        echo "<td>Rp " . number_format($row['total_price'], 2, ',', '.') . "</td>";
                        echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>Tidak ada transaksi</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <div class="footer">
            <p>&copy; 2024 Sewa Alat Musik | All Rights Reserved</p>
        </div>
    </div>
</body>
</html>
