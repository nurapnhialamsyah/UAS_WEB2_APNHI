<?php
session_start();
require('fpdf/fpdf.php'); // Make sure the FPDF library is available

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Database connection
$host = "localhost";
$user = "root";
$password = "";
$dbname = "music_rental";

$conn = new mysqli($host, $user, $password, $dbname);

// Check database connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];
$instrument_id = $_GET['instrument_id'] ?? null;

// Validate the instrument ID
if (!$instrument_id) {
    die("Instrument ID is invalid.");
}

// Retrieve instrument data from the database
$query = "SELECT * FROM instruments WHERE instrument_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $instrument_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $instrument = $result->fetch_assoc();
} else {
    die("Instrument not found.");
}

// Process rental
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $rental_date = $_POST['rental_date'];
    $return_date = $_POST['return_date'];

    // Validate the rental dates
    $start = new DateTime($rental_date);
    $end = new DateTime($return_date);
    $days = $start->diff($end)->days;

    if ($days <= 0) {
        die("Return date must be greater than rental date.");
    }

    $total_price = $instrument['price_per_day'] * $days;

    // Insert rental transaction into the rentals table
    $rental_query = "INSERT INTO rentals (user_id, instrument_id, rental_date, return_date, total_price, status) 
                     VALUES (?, ?, ?, ?, ?, 'ongoing')";
    $stmt = $conn->prepare($rental_query);
    $stmt->bind_param("iissd", $user_id, $instrument_id, $rental_date, $return_date, $total_price);
    $stmt->execute();

    // Update instrument availability to 'not available' after rental
    $update_instrument_query = "UPDATE instruments SET availability = 0 WHERE instrument_id = ?";
    $stmt = $conn->prepare($update_instrument_query);
    $stmt->bind_param("i", $instrument_id);
    $stmt->execute();

    // Generate PDF invoice
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 16);

    // Header
    $pdf->Cell(0, 10, 'Rental Invoice for Instrument', 0, 1, 'C');
    $pdf->Ln(10);

    // Invoice details
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(50, 10, 'Instrument Name:', 0, 0);
    $pdf->Cell(0, 10, $instrument['name'], 0, 1);

    $pdf->Cell(50, 10, 'Rental Date:', 0, 0);
    $pdf->Cell(0, 10, $rental_date, 0, 1);

    $pdf->Cell(50, 10, 'Return Date:', 0, 0);
    $pdf->Cell(0, 10, $return_date, 0, 1);

    $pdf->Cell(50, 10, 'Price per Day:', 0, 0);
    $pdf->Cell(0, 10, 'Rp ' . number_format($instrument['price_per_day'], 2, ',', '.'), 0, 1);

    $pdf->Cell(50, 10, 'Number of Days:', 0, 0);
    $pdf->Cell(0, 10, $days . ' days', 0, 1);

    $pdf->Cell(50, 10, 'Total Price:', 0, 0);
    $pdf->Cell(0, 10, 'Rp ' . number_format($total_price, 2, ',', '.'), 0, 1);

    $pdf->Ln(10);
    $pdf->Cell(0, 10, 'Thank you for using our rental service!', 0, 1, 'C');

    // Save and output the PDF
    $file_name = 'invoice_' . time() . '.pdf';
    $pdf->Output('D', $file_name); // 'D' for download

    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rent Instrument</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Rent Instrument: <?php echo htmlspecialchars($instrument['name']); ?></h1>
        <form method="POST">
            <div class="mb-3">
                <label for="rental_date" class="form-label">Rental Date</label>
                <input type="date" class="form-control" id="rental_date" name="rental_date" required>
            </div>
            <div class="mb-3">
                <label for="return_date" class="form-label">Return Date</label>
                <input type="date" class="form-control" id="return_date" name="return_date" required>
            </div>
            <div class="mb-3">
                <p><strong>Price per Day: </strong> Rp <?php echo number_format($instrument['price_per_day'], 2, ',', '.'); ?> per day</p>
            </div>
            <button type="submit" class="btn btn-success">Rent Instrument & Download Invoice</button>
        </form>
        <a href="instrument_list.php" class="btn btn-primary mt-3">Back to Instruments List</a>
    </div>
</body>
</html>
