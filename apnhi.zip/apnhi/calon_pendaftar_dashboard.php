<?php
session_start();

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Koneksi ke database
$host = "localhost";
$user = "root";
$password = "";
$dbname = "music_rental";

$conn = new mysqli($host, $user, $password, $dbname);

// Periksa koneksi database
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data pencarian jika ada
$search = '';
if (isset($_GET['search'])) {
    $search = $_GET['search'];
    $query = "SELECT instrument_id, name, type, price_per_day, availability, image_url 
              FROM instruments 
              WHERE name LIKE ? OR type LIKE ?";
    $stmt = $conn->prepare($query);
    $search_param = "%$search%";
    $stmt->bind_param("ss", $search_param, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    // Jika tidak ada pencarian, ambil semua data instrumen
    $query = "SELECT instrument_id, name, type, price_per_day, availability, image_url FROM instruments WHERE availability = 1";
    $result = $conn->query($query);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Calon Pendaftar</title>
    <!-- Bootstrap 5 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
        }

        .navbar {
            background: linear-gradient(90deg, #4facfe, #00f2fe);
            border-radius: 10px 10px 0 0;
        }

        .btn-outline-primary {
            border: 2px solid #00c6ff;
            color: #00c6ff;
            border-radius: 50px;
        }

        .btn-outline-primary:hover {
            background-color: #00c6ff;
            color: white;
        }

        .card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border-radius: 12px;
            overflow: hidden;
            background-color: #fff;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }

        .card-header {
            background: linear-gradient(90deg, #4facfe, #00f2fe);
            color: white;
            font-weight: 600;
        }

        .card-img-top {
            object-fit: cover;
            height: 200px;
            filter: brightness(80%);
        }

        .card-body {
            padding: 1.5rem;
        }

        .card-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: #333;
            margin-bottom: 1rem;
        }

        .card-text {
            font-size: 1rem;
            color: #666;
            margin-bottom: 1rem;
        }

        .btn-success {
            border-radius: 30px;
            font-weight: 600;
            padding: 12px 30px;
            background-color: #28a745;
            color: white;
        }

        .btn-success:hover {
            background-color: #218838;
        }

        .search-form input {
            border-radius: 50px;
            padding: 12px 20px;
            width: 80%;
        }

        .search-form button {
            border-radius: 50px;
            padding: 12px 20px;
            background-color: #00c6ff;
            color: white;
        }

        .footer {
            background-color: #f1f1f1;
            padding: 20px;
            text-align: center;
            margin-top: 50px;
        }

        .footer p {
            color: #007bff;
            font-weight: 600;
        }

        .footer a {
            text-decoration: none;
            color: #007bff;
            font-weight: 600;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        .container {
            margin-top: 80px;
        }

        .hero {
            text-align: center;
            margin-bottom: 50px;
        }

        .hero h1 {
            font-size: 3rem;
            font-weight: 700;
            color: #333;
        }

        .row {
            display: flex;
            justify-content: center;
        }

        .col-md-4 {
            margin-bottom: 30px;
        }

        .col-md-4 img {
            border-radius: 12px;
        }

        .card-footer {
            background-color: transparent;
            border: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Hero Section -->
        <div class="hero">
            <h1>Selamat Datang Bapak/Ibu</h1>
            <h2>Di Persewaan Kami</h2>
        </div>

        <!-- Navbar Section -->
        <nav class="navbar navbar-expand-lg navbar-light p-3 mb-4">
            <div class="container-fluid">
                <a href="user_dashboard.php" class="btn btn-outline-primary">Dashboard Pengguna</a>
                <a href="logout.php" class="btn btn-danger ms-auto">Logout</a>

                <!-- Search Form -->
                <form class="d-flex search-form ms-3" method="GET" action="calon_pendaftar_dashboard.php">
                    <input class="form-control" type="text" name="search" placeholder="Cari alat musik..." value="<?php echo htmlspecialchars($search); ?>">
                    <button class="btn btn-outline-success ms-2" type="submit">Cari</button>
                </form>
            </div>
        </nav>

        <!-- Instrument Cards -->
        <div class="row">
            <?php
            if ($result && $result->num_rows > 0) {
                while ($instrument = $result->fetch_assoc()) {
                    echo '<div class="col-md-4">';
                    echo '<div class="card">';
                    $image_path = !empty($instrument['image_url']) ? htmlspecialchars($instrument['image_url']) : 'placeholder.png';
                    echo '<img src="' . $image_path . '" class="card-img-top" alt="Instrument Image">';
                    echo '<div class="card-body">';
                    echo '<h5 class="card-title">' . htmlspecialchars($instrument['name']) . '</h5>';
                    echo '<p class="card-text"><strong>Tipe Instrumen:</strong> ' . htmlspecialchars($instrument['type']) . '</p>';
                    echo '<p class="card-text"><strong>Harga Sewa:</strong> Rp ' . number_format($instrument['price_per_day'], 2, ',', '.') . ' per hari</p>';
                    echo '<p class="card-text"><strong>Status:</strong> ' . ($instrument['availability'] ? 'Tersedia' : 'Tidak Tersedia') . '</p>';
                    echo '<a href="sewa_instrument.php?instrument_id=' . $instrument['instrument_id'] . '" class="btn btn-success w-100">Sewa</a>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo "<p class='text-center col-12'>Tidak ada instrumen yang tersedia atau sesuai pencarian.</p>";
            }
            ?>
        </div>
    </div>

    <!-- Footer Section -->
    <div class="footer">
        <p>&copy; 2024 Sewa Alat Musik | <a href="about.php">Tentang Kami</a></p>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
