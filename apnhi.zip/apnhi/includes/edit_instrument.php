<?php
session_start();

// Check if user is logged in and has admin role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Database connection
$host = "localhost";
$user = "root";
$password = "";
$dbname = "music_rental"; // Updated to music_rental
$conn = new mysqli($host, $user, $password, $dbname);

// Check database connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get instrument ID from URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: admin_dashboard.php");
    exit;
}

$instrument_id = intval($_GET['id']);

// Get instrument details by ID
$query = "SELECT * FROM instruments WHERE instrument_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $instrument_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Instrument data not found!";
    exit;
}

$instrument = $result->fetch_assoc();

// Process form submission to update instrument data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars(trim($_POST['name']));
    $type = htmlspecialchars(trim($_POST['type']));
    $brand = htmlspecialchars(trim($_POST['brand']));
    $price_per_day = floatval($_POST['price_per_day']);
    $availability = htmlspecialchars(trim($_POST['availability']));
    
    // Validate inputs
    if (empty($name) || empty($type) || empty($price_per_day) || empty($availability)) {
        echo "All fields must be filled!";
        exit;
    }

    // Handle image upload
    $image_url = $instrument['image_url'];  // Use old image URL if no new image is uploaded
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];
        $file_type = $_FILES['image']['type'];
        $file_tmp = $_FILES['image']['tmp_name'];
        $file_name = basename($_FILES['image']['name']);
        
        if (!in_array($file_type, $allowed_types)) {
            echo "Image must be JPG or PNG!";
            exit;
        }
        
        $target_dir = "assets/images/uploads/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $unique_name = uniqid("instrument_", true) . "." . pathinfo($file_name, PATHINFO_EXTENSION);
        $image_url = $target_dir . $unique_name;

        // Move uploaded image
        if (!move_uploaded_file($file_tmp, $image_url)) {
            echo "Failed to upload image!";
            exit;
        }
    }

    // Update instrument data in the database
    $update_query = "UPDATE instruments SET name = ?, type = ?, brand = ?, price_per_day = ?, availability = ?, image_url = ? WHERE instrument_id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("sssdssi", $name, $type, $brand, $price_per_day, $availability, $image_url, $instrument_id);
    
    if ($stmt->execute()) {
        header("Location: admin_dashboard.php?success=update");
        exit;
    } else {
        echo "Error occurred while updating data.";
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Instrument</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Edit Instrument Data</h1>
        <form method="POST" enctype="multipart/form-data">
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="name" class="form-label">Instrument Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($instrument['name']); ?>" required>
                </div>
                <div class="col-md-6">
                    <label for="type" class="form-label">Type</label>
                    <input type="text" class="form-control" id="type" name="type" value="<?php echo htmlspecialchars($instrument['type']); ?>" required>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="brand" class="form-label">Brand</label>
                    <input type="text" class="form-control" id="brand" name="brand" value="<?php echo htmlspecialchars($instrument['brand']); ?>" required>
                </div>
                <div class="col-md-6">
                    <label for="price_per_day" class="form-label">Price Per Day</label>
                    <input type="number" class="form-control" id="price_per_day" name="price_per_day" value="<?php echo htmlspecialchars($instrument['price_per_day']); ?>" required step="0.01">
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="availability" class="form-label">Availability</label>
                    <select class="form-select" id="availability" name="availability" required>
                        <option value="1" <?php echo $instrument['availability'] == 1 ? 'selected' : ''; ?>>Available</option>
                        <option value="0" <?php echo $instrument['availability'] == 0 ? 'selected' : ''; ?>>Not Available</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="image" class="form-label">Instrument Image</label>
                    <input type="file" class="form-control" id="image" name="image">
                    <p class="mt-2">Current Image: <br>
                        <img src="<?php echo htmlspecialchars($instrument['image_url']); ?>" width="150" alt="Instrument Image">
                    </p>
                </div>
            </div>
            <button type="submit" class="btn btn-success">Save Changes</button>
            <a href="admin_dashboard.php" class="btn btn-secondary">Back</a>
        </form>
    </div>
</body>
</html>
