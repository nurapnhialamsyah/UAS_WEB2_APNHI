<?php
session_start();

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Koneksi ke database
$host = "localhost";
$user = "root";
$password = "";
$dbname = "music_rental";

$conn = new mysqli($host, $user, $password, $dbname);

// Periksa koneksi database
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data pencarian jika ada
$search = '';
if (isset($_GET['search'])) {
    $search = $_GET['search'];
    $query = "SELECT instrument_id, name, type, price_per_day, availability, image_url 
              FROM instruments 
              WHERE name LIKE ? OR type LIKE ?";
    $stmt = $conn->prepare($query);
    $search_param = "%$search%";
    $stmt->bind_param("ss", $search_param, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    // Jika tidak ada pencarian, ambil semua data instrumen
    $query = "SELECT instrument_id, name, type, price_per_day, availability, image_url FROM instruments WHERE availability = 1";
    $result = $conn->query($query);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Alat Musik</title>
    <!-- Bootstrap 5 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f7fa;
        }

        .btn-outline-primary {
            border: 2px solid #00c6ff;
            color: #00c6ff;
        }

        .btn-outline-primary:hover {
            background-color: #00c6ff;
            color: white;
        }

        .card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background: linear-gradient(to right, #4facfe, #00f2fe);
            color: white;
            font-weight: 600;
        }

        .search-form input {
            border-radius: 20px;
        }

        .search-form button {
            border-radius: 20px;
        }

        .card-img-top {
            object-fit: cover;
            height: 200px;
        }

        .col-md-4 {
            margin-bottom: 20px;
        }

        .card-body {
            padding: 1.5rem;
        }

        .card-title {
            font-size: 1.25rem;
            font-weight: 600;
        }

        .card-text {
            font-size: 1rem;
        }

        .footer {
            background-color: #f1f1f1;
            padding: 20px;
            text-align: center;
        }

        .footer a {
            text-decoration: none;
            color: #007bff;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <!-- Header -->
        <h1 class="text-center mb-4">Daftar Alat Musik yang Tersedia</h1>
        
        <nav class="mb-4 d-flex justify-content-between">
            <div>
                <a href="user_dashboard.php" class="btn btn-outline-primary">Dashboard Pengguna</a>
                <a href="logout.php" class="btn btn-danger">Logout</a>
            </div>
            
            <!-- Form Pencarian -->
            <form class="d-flex search-form" method="GET" action="">
                <input class="form-control me-2" type="text" name="search" placeholder="Cari alat musik..." value="<?php echo htmlspecialchars($search); ?>">
                <button class="btn btn-outline-success" type="submit">Search</button>
            </form>
        </nav>

        <div class="row">
            <?php
            if ($result && $result->num_rows > 0) {
                while ($instrument = $result->fetch_assoc()) {
                    echo '<div class="col-md-4 mb-4">';
                    echo '<div class="card">';
                    
                    // Periksa gambar, tampilkan placeholder jika gambar kosong
                    $image_path = !empty($instrument['image_url']) ? htmlspecialchars($instrument['image_url']) : 'placeholder.png';
                    echo '<img src="' . $image_path . '" class="card-img-top" alt="Instrument Image">';
                    
                    echo '<div class="card-body">';
                    echo '<h5 class="card-title">' . htmlspecialchars($instrument['name']) . '</h5>';
                    echo '<p class="card-text"><strong>Tipe Instrumen:</strong> ' . htmlspecialchars($instrument['type']) . '</p>';
                    echo '<p class="card-text"><strong>Harga Sewa:</strong> Rp ' . number_format($instrument['price_per_day'], 2, ',', '.') . ' per hari</p>';
                    echo '<p class="card-text"><strong>Status:</strong> ' . ($instrument['availability'] ? 'Tersedia' : 'Tidak Tersedia') . '</p>';
                    echo '<a href="sewa_instrument.php?instrument_id=' . $instrument['instrument_id'] . '" class="btn btn-success">Sewa</a>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo "<p class='text-center'>Tidak ada instrumen yang tersedia atau sesuai pencarian.</p>";
            }
            ?>
        </div>
    </div>

    <div class="footer">
        <p>&copy; 2024 Sewa Alat Musik 
    </div>
</body>
</html>
