<?php
// db.php

// Menyambungkan ke database
$servername = "localhost"; // Biasanya localhost
$username = "root";        // Nama pengguna database, defaultnya 'root' untuk XAMPP
$password = "";            // Kosongkan jika tidak ada password
$dbname = "music_rental";         // Ganti dengan nama database Anda

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
