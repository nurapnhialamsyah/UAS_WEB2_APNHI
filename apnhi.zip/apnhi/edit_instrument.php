<?php
session_start();

// Cek apakah user sudah login dan memiliki role admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_level'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$host = "localhost";
$user = "root";
$password = "";
$dbname = "music_rental"; // Gunakan nama database yang sesuai

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    // Ambil data instrumen berdasarkan ID
    $instrument_query = "SELECT * FROM instruments WHERE instrument_id = ?";
    $stmt = $conn->prepare($instrument_query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $instrument = $result->fetch_assoc();
    } else {
        die("Instrumen tidak ditemukan.");
    }
} else {
    die("ID instrumen tidak ditemukan.");
}

// Proses update data instrumen
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_instrument'])) {
    $name = htmlspecialchars($_POST['name']);
    $type = htmlspecialchars($_POST['type']);
    $brand = htmlspecialchars($_POST['brand']);
    $price_per_day = floatval($_POST['price_per_day']);
    $availability = isset($_POST['availability']) ? 1 : 0; // Untuk status availability

    // Validasi file upload jika ada perubahan gambar
    $image_url = $instrument['image_url']; // Default gambar lama
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "assets/images/uploads/";
        $file_name = basename($_FILES["image"]["name"]);
        $file_type = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $image_url = $target_dir . time() . "_" . $file_name;

        // Validasi tipe file (hanya gambar yang diizinkan)
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($file_type, $allowed_types)) {
            move_uploaded_file($_FILES["image"]["tmp_name"], $image_url);
        } else {
            die("Error: File harus berupa gambar (jpg, jpeg, png, gif).");
        }
    }

    // Update data instrumen ke database
    $update_query = "UPDATE instruments SET name = ?, type = ?, brand = ?, price_per_day = ?, availability = ?, image_url = ? WHERE instrument_id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("sssdisi", $name, $type, $brand, $price_per_day, $availability, $image_url, $id);
    $stmt->execute();
    $stmt->close();

    header("Location: admin_dashboard.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Instrumen</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1 class="my-4">Edit Instrumen</h1>
        <form method="POST" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="name" class="form-label">Nama Instrumen</label>
                    <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($instrument['name']); ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="type" class="form-label">Jenis Instrumen</label>
                    <input type="text" name="type" class="form-control" value="<?php echo htmlspecialchars($instrument['type']); ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="brand" class="form-label">Merek</label>
                    <input type="text" name="brand" class="form-control" value="<?php echo htmlspecialchars($instrument['brand']); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="price_per_day" class="form-label">Harga Sewa Per Hari</label>
                    <input type="number" name="price_per_day" class="form-control" value="<?php echo htmlspecialchars($instrument['price_per_day']); ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="availability" class="form-label">Status Tersedia</label>
                    <input type="checkbox" name="availability" <?php echo ($instrument['availability'] ? 'checked' : ''); ?>>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="image" class="form-label">Gambar</label>
                    <input type="file" name="image" class="form-control" accept="image/*">
                    <img src="<?php echo htmlspecialchars($instrument['image_url']); ?>" alt="Current Image" class="mt-2" width="100">
                </div>
            </div>
            <button type="submit" name="update_instrument" class="btn btn-primary">Update Instrumen</button>
        </form>
    </div>
</body>
</html>
